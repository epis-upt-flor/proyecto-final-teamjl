<?php
    require_once("../../inc/protect.php");
    $title = "Dashboard del Administrador";
    $view = "../dashboard/contenido.php";
    include("../includes/layout.php");
?>