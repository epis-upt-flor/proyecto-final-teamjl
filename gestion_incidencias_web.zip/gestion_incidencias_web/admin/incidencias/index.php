<?php
    require_once("../../inc/protect.php");
    $title = "Listado de Incidencias";
    $view = "../incidencias/contenido.php";
    include("../includes/layout.php");
?>