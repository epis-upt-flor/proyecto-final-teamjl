<?php
    require_once("../../inc/protect.php");
    $title = "Empleados Registrados";
    $view = "../empleados/contenido.php";
    include("../includes/layout.php");
?>