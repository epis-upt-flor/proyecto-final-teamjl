<?php
    require_once("../../inc/protect.php");
    $title = "Reportes Estadísticos";
    $view = "../reporte/contenido.php";
    include("../includes/layout.php");
?>