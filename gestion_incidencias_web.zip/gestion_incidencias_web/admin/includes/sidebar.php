<div class="sidebar">
    <h5 class="text-center py-3 border-bottom">ADMINISTRADOR</h5>
    <a href="../dashboard/" class="<?= basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : '' ?>">
        <i class="bi bi-speedometer2"></i> Dashboard
    </a>
    <a href="../incidencias/">
        <i class="bi bi-exclamation-circle"></i> Ver Incidencias
    </a>
    <a href="../empleados/">
        <i class="bi bi-person-badge"></i> Ver Empleados
    </a>
    <a href="../reporte/">
        <i class="bi bi-graph-up"></i> Ver Reportes
    </a>
    <a href="../login_register/logout.php">
        <i class="bi bi-box-arrow-right"></i> Cerrar Sesión
    </a>
</div>