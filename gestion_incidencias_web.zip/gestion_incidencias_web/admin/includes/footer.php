<footer class="mt-5">
    <small>© <?= date('Y') ?> Gestión de Incidencias | Panel del Administrador</small>
</footer>