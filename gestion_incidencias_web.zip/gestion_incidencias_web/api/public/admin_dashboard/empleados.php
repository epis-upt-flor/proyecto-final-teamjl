<?php
    require_once __DIR__ . '/../../bootstrap.php';

    use App\Controllers\EmpleadoController;

    EmpleadoController::listar();
?>